from flask import Flask, render_template, request
from readOntology import get_shapes, get_formulas, get_properties

def calculate_area(formula, input_values, properties):
    """Calculate the area based on the formula and input values."""
    try:
        # Replace property names in the formula with their corresponding input values
        eval_formula = formula
        for prop in properties:
            eval_formula = eval_formula.replace(prop.lower(), str(input_values[prop]))
            eval_formula = eval_formula.replace('^', "**")

        # Evaluate the formula
        return eval(eval_formula)
    except Exception as e:
        return f"Error in calculation: {str(e)}"

app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def index():
    result = None
    selected_shape = None
    input_values = {}
    formula = None
    properties = []
    shapes = get_shapes()
    shape_names = [shape.name.split('.')[-1] for shape in shapes]

    if request.method == 'POST':
        selected_shape = request.form.get("shape")
        shape = next((s for s in shapes if s.name == selected_shape), None)
        if shape:
            formula = get_formulas(shape)[0][0] if get_formulas(shape) else "No formula available"
            properties = get_properties(shape)

            # Get property values from form
            for prop in properties:
                input_values[prop] = float(request.form.get(prop, 0))
            result = calculate_area(formula, input_values, properties)

    return render_template('index.html', shapes=shape_names, selected_shape=selected_shape,
                           formula=formula, properties=properties,
                           result=result, input_values=input_values)

if __name__ == '__main__':
    app.run(debug=True)
