from owlready2 import get_ontology

# Load the ontology from the file
onto = get_ontology("ontology.rdf").load()

def get_shapes():
    """Retrieve all shape instances from the ontology."""
    return onto.Shape.instances()

def get_formulas(shape):
    """Retrieve formulas associated with a given shape."""
    formulas = []
    if shape.hasFormula:
        for formula in shape.hasFormula:
            formulas.append(formula.formulaValue)
    return formulas

def get_properties(shape):
    """Retrieve properties associated with a given shape."""
    properties = []
    if shape.hasProperty:
        for property in shape.hasProperty:
            properties.append(property.name)
    return properties
